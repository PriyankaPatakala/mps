package com.capg.gear.dao;

import com.capg.gear.model.GearForm;

public interface IGearDao {
	
	GearForm findqueryID(Integer queryID);


	boolean textarea(Integer queryID, String textarea);

}
