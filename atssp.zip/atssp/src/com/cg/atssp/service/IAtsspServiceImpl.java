package com.cg.atssp.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.atssp.dao.IAtsspDao;
import com.cg.atssp.dto.TimeSheet;
@Service("atsspervice")
@Transactional
public class IAtsspServiceImpl implements IAtsspService {

	@Autowired
	IAtsspDao atsspdao;
	
	@Override
	public Integer TimeSheetUpload(TimeSheet ts) {
		
		Integer id=atsspdao.timeshetupload(ts);
		
		return id;
		
		
		
		
	}

}
