package com.cap.gear.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cap.gear.model.GearForm;
import com.cap.gear.service.IGearService;

@Controller
public class GearController {
	@Autowired
	IGearService serviceimpl;

	
	@RequestMapping("/homepage")
	public ModelAndView answer(@RequestParam("queryID") Integer queryID){
		System.out.println(queryID);
		GearForm query= serviceimpl.findqueryID(queryID);
		System.out.println(query);
		return new ModelAndView("answersheet","all",query);
	}
	
	@RequestMapping("/feedpage")
	public ModelAndView success(@RequestParam("queryid") Integer queryID,@RequestParam("textarea") String textarea){
		System.out.println( queryID);
		System.out.println(textarea);
		boolean id=serviceimpl.textarea(queryID,textarea);
		//if(id) {
		return new ModelAndView("sucesspage","queryId", queryID);}
		//else{return new ModelAndView("error","string","invalid");} 
	}
	//}



