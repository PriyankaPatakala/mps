package com.cap.gear.dao;

import com.cap.gear.model.GearForm;

public interface IGearDao {
	
	GearForm findqueryID(Integer queryID);


	boolean textarea(Integer queryID, String textarea);

}
