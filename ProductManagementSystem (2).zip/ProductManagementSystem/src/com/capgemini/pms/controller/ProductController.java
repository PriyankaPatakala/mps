package com.capgemini.pms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.pms.entity.Product;
import com.capgemini.pms.service.IProductservice;

@Controller
public class ProductController {

@Autowired
IProductservice service;
@RequestMapping("/home")

public ModelAndView displaypage(){
List<Product> list=service.getProductdetails();
System.out.println(list);
return new ModelAndView("product","productstorage",list);
}

@RequestMapping(value="/purchase")
public ModelAndView dispPurchase(@RequestParam("proname") String sn){
System.out.println(sn);			//to check whether String is obtained or not. it displays String in console	
return new ModelAndView("purchaseconformation", "productstorage",sn);
}

	
	
	
	
	
	
	
	
}

