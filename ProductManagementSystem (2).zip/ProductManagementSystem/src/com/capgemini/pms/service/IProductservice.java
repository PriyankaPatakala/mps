package com.capgemini.pms.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.pms.entity.Product;

public interface IProductservice {
	
	public List<Product> getProductdetails();
	

	public String findProductName();
	
	
}
