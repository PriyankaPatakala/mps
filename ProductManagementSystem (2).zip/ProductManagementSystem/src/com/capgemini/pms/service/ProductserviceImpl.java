package com.capgemini.pms.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.pms.dao.IProductdao;
import com.capgemini.pms.entity.Product;



@Service
public class ProductserviceImpl implements IProductservice {
	
	@Autowired
	IProductdao productdao;
	
	
	@Override
	public List<Product> getProductdetails() {


		return productdao.getProductdetails();
	}

	@Override
	public String findProductName() {


		return productdao.findProductName();
	}

}
