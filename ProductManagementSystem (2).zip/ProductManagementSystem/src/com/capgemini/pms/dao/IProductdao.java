package com.capgemini.pms.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.pms.entity.Product;


public interface IProductdao {

	public List<Product> getProductdetails();
	
	public String findProductName();

	
	
}
