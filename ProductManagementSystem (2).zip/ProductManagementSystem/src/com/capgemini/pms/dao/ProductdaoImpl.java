package com.capgemini.pms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.pms.entity.Product;
import com.capgemini.pms.service.IProductservice;

@Repository
public class ProductdaoImpl implements IProductdao {
	
    @PersistenceContext
	EntityManager em;
    
    
    @Override
	public List<Product> getProductdetails() {
    	Query query= em.createQuery("FROM Product");
		List<Product> list=query.getResultList();
		return list;
		
	}

		

	@Override
	public String findProductName() {

			String jpql ="Select productname from Product productname where id = 1";
			TypedQuery<String> query =em.createQuery(jpql,String.class);
			//Query String  =em.createQuery(jpql,String.class);
			String productName = (String) query.getSingleResult();
			return productName;
		
			
	}

	
	
	
}
