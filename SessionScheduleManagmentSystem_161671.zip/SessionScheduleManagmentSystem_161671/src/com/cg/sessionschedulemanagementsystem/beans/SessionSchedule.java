package com.cg.sessionschedulemanagementsystem.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="ScheduledSessions")
public class SessionSchedule {

	@Id
	@Column(name="id")
	Integer sessionId;
	
	@Column(name="name")
	String sessionName;
	
	@Column(name="duration")
	Integer sessionDuration;
	
	@Column(name="faculty")
	String sessionFaculty;
	
	@Column(name="mode1")
	String sessionMode;
	
	public SessionSchedule() {
		// TODO Auto-generated constructor stub
	}

	public SessionSchedule(Integer sessionId, String sessionName,
			Integer sessionDuration, String sessionFaculty, String sessionMode) {
		super();
		this.sessionId = sessionId;
		this.sessionName = sessionName;
		this.sessionDuration = sessionDuration;
		this.sessionFaculty = sessionFaculty;
		this.sessionMode = sessionMode;
	}

	public Integer getSessionId() {
		return sessionId;
	}

	public void setSessionId(Integer sessionId) {
		this.sessionId = sessionId;
	}

	public String getSessionName() {
		return sessionName;
	}

	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}

	public Integer getSessionDuration() {
		return sessionDuration;
	}

	public void setSessionDuration(Integer sessionDuration) {
		this.sessionDuration = sessionDuration;
	}

	public String getSessionFaculty() {
		return sessionFaculty;
	}

	public void setSessionFaculty(String sessionFaculty) {
		this.sessionFaculty = sessionFaculty;
	}

	public String getSessionMode() {
		return sessionMode;
	}

	public void setSessionMode(String sessionMode) {
		this.sessionMode = sessionMode;
	}

	@Override
	public String toString() {
		return "SessionSchedule [sessionId=" + sessionId + ", sessionName="
				+ sessionName + ", sessionDuration=" + sessionDuration
				+ ", sessionFaculty=" + sessionFaculty + ", sessionMode="
				+ sessionMode + "]";
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
}
